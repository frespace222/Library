// SPDX-License-Identifier: MIT
// OpenZeppelin Contracts (last updated v5.7.0) (utils/cryptography/signers/SignerWebAuthn.sol)

pragma solidity ^0.8.24;

import {SignerP256Upgradeable} from "./SignerP256Upgradeable.sol";
import {WebAuthn} from "@openzeppelin/contracts/utils/cryptography/WebAuthn.sol";
import {Initializable} from "@openzeppelin/contracts/proxy/utils/Initializable.sol";

/**
 * @dev Implementation of {SignerP256} that supports WebAuthn authentication assertions.
 *
 * This contract enables signature validation using WebAuthn authentication assertions,
 * leveraging the P256 public key stored in the contract.
 *
 * The signature is expected to be an abi-encoded {WebAuthn-WebAuthnAuth} struct.
 *
 * Example usage:
 *
 * ```solidity
 * contract MyAccountWebAuthn is Account, SignerWebAuthn, Initializable {
 *     function initialize(bytes32 qx, bytes32 qy) public initializer {
 *         _setSigner(qx, qy);
 *     }
 * }
 * ```
 *
 * IMPORTANT: Failing to call {_setSigner} either during construction (if used standalone)
 * or during initialization (if used as a clone) may leave the signer either front-runnable or unusable.
 */
abstract contract SignerWebAuthnUpgradeable is Initializable, SignerP256Upgradeable {
    function __SignerWebAuthn_init() internal onlyInitializing {
    }

    function __SignerWebAuthn_init_unchained() internal onlyInitializing {
    }
    /**
     * @dev Validates a raw signature using the WebAuthn authentication assertion.
     *
     * Returns `false` if the signature is not a valid WebAuthn authentication assertion.
     */
    function _rawSignatureValidation(
        bytes32 hash,
        bytes calldata signature
    ) internal view virtual override returns (bool) {
        (bool decodeSuccess, WebAuthn.WebAuthnAuth calldata auth) = WebAuthn.tryDecodeAuth(signature);
        if (!decodeSuccess) return false;
        (bytes32 qx, bytes32 qy) = signer();
        return WebAuthn.verify(abi.encodePacked(hash), auth, qx, qy);
    }
}
