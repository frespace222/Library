// SPDX-License-Identifier: MIT
// OpenZeppelin Contracts (last updated v5.7.0) (token/ERC1155/extensions/ERC1155Burnable.sol)

pragma solidity ^0.8.24;

import {ERC1155Upgradeable} from "../ERC1155Upgradeable.sol";
import {Initializable} from "@openzeppelin/contracts/proxy/utils/Initializable.sol";

/**
 * @dev Extension of {ERC1155} that allows token holders to destroy both their
 * own tokens and those that they have been approved to use.
 */
abstract contract ERC1155BurnableUpgradeable is Initializable, ERC1155Upgradeable {
    function __ERC1155Burnable_init() internal onlyInitializing {
    }

    function __ERC1155Burnable_init_unchained() internal onlyInitializing {
    }
    function burn(address account, uint256 id, uint256 value) public virtual {
        _checkAuthorized(_msgSender(), account);
        _burn(account, id, value);
    }

    function burnBatch(address account, uint256[] memory ids, uint256[] memory values) public virtual {
        _checkAuthorized(_msgSender(), account);
        _burnBatch(account, ids, values);
    }
}
